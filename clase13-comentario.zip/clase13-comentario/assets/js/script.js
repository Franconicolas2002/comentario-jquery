
//JS Nativo
/*  
<script>

    function comentar(event) {
        event.preventDefault(); // Evita que se recargue la página

        let nombre = document.getElementById('nombre').value;
        let comentario = document.getElementById('comentario').value;

        // Condición por si falta info en el form
        if (nombre == '') {
            alert('Para comentar, debes completar el formulario');
            return;
        }

        if (comentario == '') {
            alert('Para comentar, debes completar el formulario');
            return;
        }

        // Crea un nuevo elemento de parrafo 
        let nuevoComentario = document.createElement('p');
        nuevoComentario.innerHTML = ('<strong>' + nombre + ':</strong><br>  ' + comentario); // innerHTML: Para definir el contenido parrafo

        let cajaComentario = document.getElementById('caja-comentario');
        cajaComentario.appendChild(nuevoComentario); // appendChild: Agrega el nuevo comentario a la caja

        document.getElementById('form-comentario').reset(); // reset(): Borra los datos ingresados del form
        return;
    }

</script> 
*/

//Jquery
console.log('funciona');

$(document).ready(function(){

    function comentar(event){
        event.preventDefault();

        let nombre = $('#nombre').val();
        let comentario = $('#comentario').val();

        if (nombre == '') {
            alert('Para comentar, debes completar el formulario');
            return;
        }

        if (comentario == '') {
            alert('Para comentar, debes completar el formulario');
            return;
        }

        let nuevoComentario = $('<p>');
        nuevoComentario.html('<strong>' + nombre + ':</strong><br>  ' + comentario);

        let cajaComentario = $('#caja-comentario');
        cajaComentario.append(nuevoComentario); 

        $('#form-comentario').reset(); // No me funciona el borrar los datos ingresados
        return;
    }

    // Enlaza el form con el evento submit
    $('#form-comentario').on('submit', comentar);// la funcion sin parentesis, solo la referencia, para no ejecutarla directamente
})